import sys
print("hello")
sys.stdout.flush()
