﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOI4test
{
    internal class StateEdit
    {
        public void CompileStateInfo(int id, Dictionary<int, Dictionary<string, Object>> stateDict)
        {
            
        }

        
    }
}
